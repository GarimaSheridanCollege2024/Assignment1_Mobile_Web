import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-canada-summary',
  templateUrl: './canada-summary.page.html',
  styleUrls: ['./canada-summary.page.scss'],
})
export class CanadaSummaryPage implements OnInit {
  constructor() { }

  ngOnInit() { }
}
